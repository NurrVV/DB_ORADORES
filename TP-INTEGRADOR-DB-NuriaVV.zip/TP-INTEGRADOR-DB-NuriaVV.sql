-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.1.0 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.5.0.6677
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping data for table integrador_cac.oradores: ~10 rows (approximately)
INSERT INTO `oradores` (`id_orador`, `nombre`, `apellido`, `mail`, `tema`, `fecha_alta`) VALUES
	(1, 'Carlotta', 'Pelmazza', 'carpel@mail.com', 'Python y Galletitas', '2023-10-02'),
	(2, 'Enriquetto', 'Fazzulio', 'enrfaz@mail.com', 'Java y Canelones', '2023-12-03'),
	(3, 'Ruperta', 'Solettia', 'rupsol@mail.com', 'C++ y Ravioles', '2023-09-04'),
	(4, 'Raquelia', 'Risotta', 'raqris@mail.com', 'Javascript y Faina', '2023-10-02'),
	(5, 'Ramoncio', 'Capadelio', 'ramcap@mail.com', 'Binary Superstition', '2023-11-10'),
	(6, 'Fulgencio', 'Pimpollo', 'fulpim@mail.com', 'Debugger para insectos', '2023-05-03'),
	(7, 'Mariotta', 'Delucca', 'mardel@mail.com', 'Assembly desarmado', '2023-08-11'),
	(8, 'Narciso', 'Menta', 'narmen@mail.com', 'Malware y Maleficios', '2023-10-13'),
	(9, 'Geranio', 'Tartello', 'gertal@mail.com', 'HTML con dislexia', '2023-10-02'),
	(10, 'Juanetto', 'Chorizzo', 'juacho@mail.com', 'SQL y Pistaccio', '2023-10-02');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
